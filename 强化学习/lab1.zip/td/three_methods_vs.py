import gym
import itertools
import matplotlib
import numpy as np
import random
import pandas as pd
import sys

from matplotlib import pyplot as plt

if "../" not in sys.path:
  sys.path.append("../") 

from collections import defaultdict
from lib.envs.cliff_walking import CliffWalkingEnv
from lib import plotting

matplotlib.style.use('ggplot')

env = CliffWalkingEnv()

def make_epsilon_greedy_policy(Q, epsilon, nA):
    """
    Creates an epsilon-greedy policy based on a given Q-function and epsilon.
    
    Args:
        Q: A dictionary that maps from state -> action-values.
            Each value is a numpy array of length nA (see below)
        epsilon: The probability to select a random action . float between 0 and 1.
        nA: Number of actions in the environment.
    
    Returns:
        A function that takes the observation as an argument and returns
        the probabilities for each action in the form of a numpy array of length nA.
    
    """
    def policy_fn(observation):
        A = np.ones(nA, dtype=float) * epsilon / nA
        best_action = np.argmax(Q[observation])
        A[best_action] += (1.0 - epsilon)
        return A
    return policy_fn


def double_make_epsilon_greedy_policy(Q1, Q2, epsilon, nA):
    """
    Creates an epsilon-greedy policy based on a given Q-function and epsilon.

    Args:
        Q: A dictionary that maps from state -> action-values.
            Each value is a numpy array of length nA (see below)
        epsilon: The probability to select a random action . float between 0 and 1.
        nA: Number of actions in the environment.

    Returns:
        A function that takes the observation as an argument and returns
        the probabilities for each action in the form of a numpy array of length nA.

    """

    def policy_fn(observation):
        A = np.ones(nA, dtype=float) * epsilon / nA
        best_action1 = np.argmax(Q1[observation])
        best_action2 = np.argmax(Q2[observation])
        if Q1[observation][best_action1] >= Q2[observation][best_action2]:
            A[best_action1] += (1.0 - epsilon)
        else:
            A[best_action2] += (1.0 - epsilon)
        return A

    return policy_fn


def sarsa(env, num_episodes, discount_factor=1.0, alpha=0.5, epsilon=0.1):
    """
    SARSA algorithm: On-policy TD control. Finds the optimal epsilon-greedy policy.
    
    Args:
        env: OpenAI environment.
        num_episodes: Number of episodes to run for.
        discount_factor: Gamma discount factor.
        alpha: TD learning rate.
        epsilon: Chance the sample a random action. Float betwen 0 and 1.
    
    Returns:
        A tuple (Q, stats).
        Q is the optimal action-value function, a dictionary mapping state -> action values.
        stats is an EpisodeStats object with two numpy arrays for episode_lengths and episode_rewards.
    """
    
    # The final action-value function.
    # A nested dictionary that maps state -> (action -> action-value).
    Q = defaultdict(lambda: np.zeros(env.action_space.n))
    
    # Keeps track of useful statistics
    stats = plotting.EpisodeStats(
        episode_lengths=np.zeros(num_episodes),
        episode_rewards=np.zeros(num_episodes))

    # The policy we're following
    policy = make_epsilon_greedy_policy(Q, epsilon, env.action_space.n)
    
    for i_episode in range(num_episodes):
        # Print out which episode we're on, useful for debugging.
        if (i_episode + 1) % 100 == 0:
            print("\rEpisode {}/{}.".format(i_episode + 1, num_episodes), end="")
            sys.stdout.flush()

        # Reset the environment
        state = env.reset()
        action_probablilities = policy(state)
        action = np.random.choice(np.arange(len(action_probablilities)) , p=action_probablilities)
        # One step in the environment
        for t in itertools.count():
#########################################Implement your code here#######################################################################################
            # step 1 : Take a step( 1 line code, tips : env.step() )
            next_state,reward,done,_=env.step(action)
            # step 2 : Pick the next action
            next_action_probablilities=policy(next_state)
            next_action=np.random.choice(np.arange(len(next_action_probablilities)),p=next_action_probablilities)
            # Update statistics
            stats.episode_rewards[i_episode] += reward
            stats.episode_lengths[i_episode] = t
            
            # step 3 : TD Update
            # compute Q value      
            TD_target = reward + discount_factor * Q[next_state][next_action]
            TD_delta = TD_target - Q[state][action]
            Q[state][action] += alpha*TD_delta
            if done:
                break
            state=next_state
            action=next_action
#########################################Implement your code here end#####################################################################################
    return Q, stats

def q_learning(env, num_episodes, discount_factor=1.0, alpha=0.5, epsilon=0.1):
    """
    Q-Learning algorithm: Off-policy TD control. Finds the optimal greedy policy
    while following an epsilon-greedy policy
    
    Args:
        env: OpenAI environment.
        num_episodes: Number of episodes to run for.
        discount_factor: Gamma discount factor.
        alpha: TD learning rate.
        epsilon: Chance the sample a random action. Float betwen 0 and 1.
    
    Returns:
        A tuple (Q, episode_lengths).
        Q is the optimal action-value function, a dictionary mapping state -> action values.
        stats is an EpisodeStats object with two numpy arrays for episode_lengths and episode_rewards.
    """
    
    # The final action-value function.
    # A nested dictionary that maps state -> (action -> action-value).
    Q = defaultdict(lambda: np.zeros(env.action_space.n))

    # Keeps track of useful statistics
    stats = plotting.EpisodeStats(
        episode_lengths=np.zeros(num_episodes),
        episode_rewards=np.zeros(num_episodes))    
    
    # The policy we're following
    policy = make_epsilon_greedy_policy(Q, epsilon, env.action_space.n)
    
    for i_episode in range(num_episodes):
        # Print out which episode we're on, useful for debugging.
        if (i_episode + 1) % 100 == 0:
            print("\rEpisode {}/{}.".format(i_episode + 1, num_episodes), end="")
            sys.stdout.flush()
        
        # Reset the environment and pick the first action
        state = env.reset()

        # One step in the environment
        # total_reward = 0.0
        for t in itertools.count():
 ########################################Implement your code here##########################################################################       
            # step 1 : Take a step
            action_probalities = policy(state)
            action = np.random.choice(np.arange(len(action_probalities)), p=action_probalities)
            next_state, reward, done, _ = env.step(action)
            # Update statistics
            stats.episode_rewards[i_episode] += reward
            stats.episode_lengths[i_episode] = t
            
            # step 2 : TD Update
            next_best_action = np.argmax(Q[next_state])
            TD_target = reward + discount_factor*Q[next_state][next_best_action]
            TD_error = TD_target - Q[state][action]
            Q[state][action] += alpha * TD_error
            if done:
                break
            state = next_state
#######################################Imlement your code end###########################################################################
    return Q, stats


def double_q_learning(env, num_episodes, discount_factor=1.0, alpha=0.5, epsilon=0.1):
    """
    Q-Learning algorithm: Off-policy TD control. Finds the optimal greedy policy
    while following an epsilon-greedy policy
    
    Args:
        env: OpenAI environment.
        num_episodes: Number of episodes to run for.
        discount_factor: Gamma discount factor.
        alpha: TD learning rate.
        epsilon: Chance the sample a random action. Float betwen 0 and 1.
    
    Returns:
        A tuple (Q, episode_lengths).
        Q is the optimal action-value function, a dictionary mapping state -> action values.
        stats is an EpisodeStats object with two numpy arrays for episode_lengths and episode_rewards.
    """
    
    # The final action-value function.
    # A nested dictionary that maps state -> (action -> action-value).
    Q1 = defaultdict(lambda: np.zeros(env.action_space.n))
    Q2 = defaultdict(lambda: np.zeros(env.action_space.n))
    # Keeps track of useful statistics
    stats = plotting.EpisodeStats(
        episode_lengths=np.zeros(num_episodes),
        episode_rewards=np.zeros(num_episodes))    
    
    # The policy we're following
    policy = double_make_epsilon_greedy_policy(Q1, Q2, epsilon, env.action_space.n)
    
    for i_episode in range(num_episodes):
        # Print out which episode we're on, useful for debugging.
        if (i_episode + 1) % 100 == 0:
            print("\rEpisode {}/{}.".format(i_episode + 1, num_episodes), end="")
            sys.stdout.flush()
        
        # Reset the environment and pick the first action
        state = env.reset()

        # One step in the environment
        # total_reward = 0.
        for t in itertools.count():
 ########################################Implement your code here##########################################################################
            # step 1 : Take a step
            action_probalities = policy(state)
            action = np.random.choice(np.arange(len(action_probalities)), p=action_probalities)
            next_state, reward, done, _ = env.step(action)
            # Update statistics
            stats.episode_rewards[i_episode] += reward
            stats.episode_lengths[i_episode] = t
            
            # step 2 : TD Update
            if random.random() > 0.5:
                next_best_action = np.argmax(Q1[next_state])
                TD_target = reward+discount_factor*Q2[next_state][next_best_action]
                TD_error = TD_target-Q1[state][action]
                Q1[state][action] += alpha*TD_error 
            else:
                next_best_action = np.argmax(Q2[next_state])
                TD_target = reward+discount_factor*Q1[next_state][next_best_action]
                TD_error = TD_target-Q2[state][action]
                Q2[state][action] += alpha*TD_error 
            if done:
                break
            state = next_state
#######################################Imlement your code end###########################################################################
    return stats


def plot_reward(s1,s2,s3):
    sw = 1
    fig = plt.figure(figsize=(10, 5))
    r1 = pd.Series(s1.episode_rewards).rolling(sw, min_periods=sw).mean()
    r2 = pd.Series(s2.episode_rewards).rolling(sw, min_periods=sw).mean()
    r3 = pd.Series(s3.episode_rewards).rolling(sw, min_periods=sw).mean()
    plt.plot(r1,'r')
    plt.plot(r2,'g')
    plt.plot(r3,'b')
    plt.xlabel("Episode")
    plt.ylabel("Episode Reward (Smoothed)")
    plt.title("Episode Reward over Time (Smoothed over window size {})".format(sw))
    plt.legend(('SARSA','Q-learning','Double-Q-learning'))
    plt.show(fig)
Q, sarsa_ans = sarsa(env, 500)
Q, qlearning_ans = q_learning(env, 500)
double_qlearning_ans = double_q_learning(env, 500)
plot_reward(sarsa_ans, qlearning_ans, double_qlearning_ans)